(function () {
  var parent = document.querySelector("#rangeSlider");
  if (!parent) return;

  var rangeS = parent.querySelectorAll("input[type=range]"),
      numberS = parent.querySelectorAll("input[type=number]");

  if (rangeS.length < 2 || numberS.length < 2) return;

  rangeS.forEach(function (el) {
    el.oninput = function () {
      var slide1 = parseFloat(rangeS[0].value),
          slide2 = parseFloat(rangeS[1].value);

      if (slide1 > slide2) {
        [slide1, slide2] = [slide2, slide1];
      }

      numberS[0].value = slide1;
      numberS[1].value = slide2;
    };
  });

  numberS.forEach(function (el) {
    el.oninput = function () {
      var number1 = parseFloat(numberS[0].value),
          number2 = parseFloat(numberS[1].value);

      if (number1 > number2) {
        var tmp = number1;
        numberS[0].value = number2;
        numberS[1].value = tmp;
      }

      rangeS[0].value = number1;
      rangeS[1].value = number2;
    };
  });
})();

// gsap reveal (تضمین وجود)
if (window.gsap && document.querySelectorAll('.reveal').length) {
  gsap.registerPlugin(ScrollTrigger);
  let revealContainers = document.querySelectorAll(".reveal");
  revealContainers.forEach((container) => {
    let image = container.querySelector("img");
    if (!image) return; // اگر تصویر وجود نداشت اجرا نکن
    let tl = gsap.timeline({scrollTrigger:{trigger:container, toggleActions:"play none none none"}});
    tl.set(container, {autoAlpha:1});
    tl.from(container, 1.5, {xPercent:-100, ease:Power2.out});
    tl.from(image, 1.5, {xPercent:100, scale:1.3, delay:-1.5, ease:Power2.out});
  });
}

// search area
document.addEventListener('DOMContentLoaded', function() {
  let searchToggle = document.getElementById('search-toggle');
  let searchBar = document.getElementById('search-bar');
  let searchIcon = document.getElementById('search-icon');
  let closeIcon = document.getElementById('close-icon');

  if (searchToggle && searchBar && searchIcon && closeIcon) {
    searchToggle.addEventListener('click', function() {
      searchBar.classList.toggle('active');
      searchBar.classList.toggle('hidden');
      searchToggle.classList.toggle('active');
      searchIcon.classList.toggle('hidden');
      closeIcon.classList.toggle('hidden');
      // فیلد سرچ اینپوت
      let inp = searchBar.querySelector('input');
      if (searchBar.classList.contains('active') && inp) {
        inp.focus();
      }
    });
  }
});

// لیست به عکس
let listItems = document.querySelectorAll('.list-container li');
let images = document.querySelectorAll('.image-container .image');
if (listItems.length && images.length) {
  listItems.forEach(item => {
    item.addEventListener('mouseover', () => {
      const targetImageId = item.getAttribute('data-image');
      images.forEach(div => {
        div.classList.remove('active');
        if (div.id === targetImageId) {
          div.classList.add('active');
        }
      });
    });
  });
}

// preloader
let preloader = document.querySelector('.preloader');
if(preloader) {
  let preloaderOuter = preloader.querySelector('.outer');
  let logo = preloader.querySelector('.logo');
  let loaderDashoffsetTotal = 502;
  let loaded = 0;
  let total = 10;

  function onProgress() {
    if (!preloaderOuter) return;
    let percentLoaded = Math.round((loaded / total) * 100);
    let calc = (loaderDashoffsetTotal / 100);
    let percent = Math.round(calc * percentLoaded);
    let offset = loaderDashoffsetTotal - percent;
    preloaderOuter.style.strokeDashoffset = offset + 'px';
  }

  function onDone() {
    if (!preloaderOuter || !logo) return;
    addClass(preloader, 'out');
    removeClass(logo, 'fade-in');
    addClass(logo, 'fade-out');
    setTimeout(() => {
      loaded = 0;
      removeClass(preloader, 'out');
      addClass(logo, 'fade-in');
      removeClass(logo, 'fade-out');
      preloaderOuter.style.strokeDashoffset = loaderDashoffsetTotal + 'px';
      removeClass(preloaderOuter, 'loading');
      init();
    }, 1000);
  }

  function onStart() {
    let startLength = loaderDashoffsetTotal + 'px';
    preloaderOuter.style.strokeDashoffset = startLength;
    preloaderOuter.style.opacity = 1;
    setTimeout(() => {
      let newLength = loaderDashoffsetTotal + 'px';
      preloaderOuter.style.strokeDashoffset = newLength;
      addClass(preloaderOuter, 'loading');
      loadImages();
    }, 500);
  }

  function loadImages() { load(); }

  function load() {
    loaded++;
    onProgress();

    if (loaded == total) {
      setTimeout(() => {
        onDone();
      }, 1000);
    } else {
      setTimeout(() => {
        load();
      }, 100);
    }
  }
  onStart();
}

// addClass و removeClass مطابق با قبل (نیازی به تغییر نیست)
