document.querySelectorAll('.accordion-button').forEach(button => {
  button.addEventListener('click', function () {
      const isOpen = this.getAttribute('aria-expanded') === 'true';

      // بستن همه آکاردئون‌ها
      document.querySelectorAll('.accordion-button').forEach(btn => {
          btn.setAttribute('aria-expanded', 'false');
          btn.nextElementSibling.style.maxHeight = '0';
      });

      // اگر کلیک‌شده بسته بود، باز شود
      if (!isOpen) {
          this.setAttribute('aria-expanded', 'true');
          this.nextElementSibling.style.maxHeight = this.nextElementSibling.scrollHeight + "px";
      }
  });
});
