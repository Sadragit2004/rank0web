  function showReplyForm(commentId, senderName) {
        // حذف هر فرم پاسخ قبلی
        let existingForm = document.querySelector(".reply-form-container");
        if (existingForm) {
            existingForm.remove();
        }

        // ایجاد فرم جدید
        let replyForm = document.createElement("div");
        replyForm.classList.add("reply-form-container");
        replyForm.innerHTML = `
            <form class="reply-form" action="{% url 'mag:show_detail_group' group_slug=mag.group.slug slug=mag.slug %}" method="post">
                {% csrf_token %}
                <input type="hidden" name="parent_id" value="${commentId}">
                <div class="reply-header">
                    <span>پاسخ به <strong>${senderName}</strong></span>
                    <button type="button" class="close-reply" onclick="closeReplyForm()">✖</button>
                </div>
                <div class="single-input">
                    <textarea name="text" rows="3" placeholder="پاسخ به ${senderName}..." required></textarea>
                </div>
                <div class="reply-footer">
                    <button class="reply-btn" type="submit">ارسال پاسخ</button>
                </div>
            </form>
        `;

        // پیدا کردن کامنت مربوطه و اضافه کردن فرم
        let commentBox = document.querySelector(`[data-comment-id="${commentId}"]`);
        if (commentBox) {
            commentBox.appendChild(replyForm);
            setTimeout(() => replyForm.classList.add("show"), 10); // انیمیشن باز شدن
        }
    }

    function closeReplyForm() {
        let replyForm = document.querySelector(".reply-form-container");
        if (replyForm) {
            replyForm.classList.remove("show");
            setTimeout(() => replyForm.remove(), 300); // انیمیشن بسته شدن
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        const images = document.querySelectorAll("img");

        if ("loading" in HTMLImageElement.prototype) {
            images.forEach(img => img.setAttribute("loading", "lazy"));
        } else {
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.src = entry.target.dataset.src;
                        observer.unobserve(entry.target);
                    }
                });
            });

            images.forEach(img => {
                img.dataset.src = img.src;
                img.src = "";
                observer.observe(img);
            });
        }
    });

  document.addEventListener("DOMContentLoaded", function () {
        // جمع‌آوری عناوین h2
        const topicList = document.getElementById("topic-list");
        const headings = document.querySelectorAll("article h2"); // تمام h2 های موجود در مقاله

        // افزودن عناوین به لیست
        headings.forEach((heading, index) => {
            const listItem = document.createElement("li");
            const anchor = document.createElement("a");

            // مقدار متن و لینک دهی به هدر
            anchor.textContent = heading.textContent.trim();
            anchor.href = `#heading-${index}`;
            anchor.dataset.index = index;

            // افزودن آیتم به لیست
            listItem.appendChild(anchor);
            topicList.appendChild(listItem);

            // افزودن ID به هدر برای لینک‌دهی
            heading.id = `heading-${index}`;
        });

        // اضافه کردن قابلیت اسکرول نرم به لینک‌ها
        topicList.addEventListener("click", function (event) {
            if (event.target.tagName === "A") {
                event.preventDefault();
                const targetId = event.target.getAttribute("href").substring(1);
                const targetElement = document.getElementById(targetId);

                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: "smooth", block: "center" });
                }
            }
        });
    });
    
    
    const svgIcon = `
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
 class="bi bi-copy" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M4 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM2 5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-1h1v1a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h1v1z"/>
</svg>`;

document.querySelectorAll('pre').forEach(function(pre) {
  // ایجاد رپر اگر وجود نداشت
  if (!pre.parentElement.classList.contains('pre-wrapper')) {
    let wrapper = document.createElement('div');
    wrapper.className = 'pre-wrapper';
    pre.parentNode.insertBefore(wrapper, pre);
    wrapper.appendChild(pre);
  }
  // دکمه SVG را ایجاد و اضافه کن
  let btn = document.createElement('button');
  btn.className = 'copy-svg-btn';
  btn.innerHTML = svgIcon;
  btn.title = 'کپی کد';
  btn.onclick = function() {
    navigator.clipboard.writeText(pre.innerText).then(() => {
      btn.classList.add('copied');
      btn.blur();
      let old = btn.innerHTML;
      btn.innerHTML = '✔️'; // تیک بعد از کپی
      setTimeout(() => {
        btn.classList.remove('copied');
        btn.innerHTML = svgIcon;
      }, 1200);
    });
  };
  pre.parentElement.appendChild(btn);
});


document.addEventListener("DOMContentLoaded", function () {
    // جمع‌آوری عناوین h2
    const topicList = document.getElementById("topic-list");
    const mobileTopicList = document.querySelector("#mobile-topic-box .mobile-topic-list");
    const headings = document.querySelectorAll("article h2");

    // پاک کردن لیست قبلی
    topicList.innerHTML = '';
    mobileTopicList.innerHTML = '';

    // پرکردن لیست دسکتاپ و موبایل
    headings.forEach((heading, index) => {
        // ساخت لیست دسکتاپ
        const listItem = document.createElement("li");
        const anchor = document.createElement("a");
        anchor.textContent = heading.textContent.trim();
        anchor.href = `#heading-${index}`;
        anchor.dataset.index = index;
        listItem.appendChild(anchor);
        topicList.appendChild(listItem);

        // ساخت لیست موبایل
        const mobileListItem = listItem.cloneNode(true);
        mobileTopicList.appendChild(mobileListItem);

        // اضافه کردن ID به هدر برای لینک‌دهی
        heading.id = `heading-${index}`;
    });

    // اسکرول نرم دسکتاپ
    topicList.addEventListener("click", function (event) {
        if (event.target.tagName === "A") {
            event.preventDefault();
            const targetId = event.target.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        }
    });

    // اسکرول نرم موبایل و بستن لیست بعد از انتخاب
    mobileTopicList.addEventListener("click", function (event) {
        if (event.target.tagName === "A") {
            event.preventDefault();
            const targetId = event.target.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: "smooth", block: "center" });
            }
            mobileTopicList.classList.remove('open');
        }
    });

    // باز و بسته شدن منو در موبایل
    document.querySelector('.mobile-topic-trigger').addEventListener('click', function () {
        mobileTopicList.classList.toggle('open');
    });
});



  let audio = null;
let textSegments = [];
let currentHighlight = null;
let animationFrameId = null;
const HIGHLIGHT_SPEED = 1.1;
const WORD_SPACING = ' '; // فاصله بین کلمات

function openAudioModal() {
  const modal = document.getElementById('audioModal');
  modal.style.display = 'block';
  
  audio = document.getElementById('audioPlayer');
  const audioTextElement = document.getElementById('audioText');
  
  resetHighlight();
  prepareTextForHighlighting(audioTextElement);
  
  audio.play().catch(e => console.log("Autoplay blocked:", e));
  
  // رویداد پایان صوت
  audio.addEventListener('ended', closeAudioModal);
  
  animationFrameId = requestAnimationFrame(updateHighlight);
}

function prepareTextForHighlighting(element) {
  const text = element.textContent;
  // تقسیم متن با حفظ فاصله‌ها
  const segments = text.split(/([\u0600-\u06FF]+|\S+)/).filter(s => s.trim().length > 0 || s === ' ');
  
  element.innerHTML = segments.map(segment => {
    if (segment === ' ') {
      return '<span class="text-space"> </span>';
    }
    return `<span class="text-word">${segment}</span>`;
  }).join('');
  
  textSegments = Array.from(element.querySelectorAll('.text-word'));
}

function updateHighlight() {
  if (!audio || audio.paused) {
    cancelAnimationFrame(animationFrameId);
    return;
  }
  
  const duration = audio.duration;
  const currentTime = audio.currentTime * HIGHLIGHT_SPEED;
  const progress = Math.min(currentTime / duration, 0.999);
  const segmentIndex = Math.floor(progress * textSegments.length);
  
  if (currentHighlight) {
    currentHighlight.classList.remove('highlight');
  }
  
  if (segmentIndex < textSegments.length) {
    currentHighlight = textSegments[segmentIndex];
    currentHighlight.classList.add('highlight');
    
    // اسکرول نرم
    currentHighlight.scrollIntoView({
      behavior: 'smooth',
      block: 'center'
    });
  }
  
  animationFrameId = requestAnimationFrame(updateHighlight);
}

function closeAudioModal() {
  resetHighlight();
  if (audio) {
    audio.pause();
    audio.currentTime = 0;
    audio.removeEventListener('ended', closeAudioModal);
  }
  document.getElementById('audioModal').style.display = 'none';
}

function resetHighlight() {
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
  if (currentHighlight) {
    currentHighlight.classList.remove('highlight');
    currentHighlight = null;
  }
}

// رویداد کلیک برای دکمه بستن
document.querySelector('.close-modal').addEventListener('click', closeAudioModal);

// رویداد کلیک خارج از مودال
window.addEventListener('click', function(event) {
  if (event.target === document.getElementById('audioModal')) {
    closeAudioModal();
  }
});
